package com.sonata;

public class ServletInitializer {

}
