package com.sonata.one;

public class Employee {
	
	private int Id;
	private String name;
	private Address add;
	
	public Employee(int Id,String name,Address add) {
		super();
		this.Id = Id;
		this.name=name;
		this.add = add;
		
	}
	
	public void display() {
		System.out.println(add.toString());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
