package com.sonata.DAOIntf;

import java.util.List;

import com.sonata.Model.Login;


public interface LoginIntf {
	public List<Login>getAllUsers();
}