package com.jpassion.di;

public class BeanConfiguration {

}
