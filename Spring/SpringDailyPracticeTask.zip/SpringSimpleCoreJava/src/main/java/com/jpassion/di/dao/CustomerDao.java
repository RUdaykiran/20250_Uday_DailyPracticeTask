package com.jpassion.di.dao;

public interface CustomerDao {
	public String getCustomerName();
}