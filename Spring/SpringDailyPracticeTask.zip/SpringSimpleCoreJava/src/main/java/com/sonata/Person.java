package com.sonata;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Person {
	private String name = "Uday";
	private int age = 40;
	private float heoght = 5.6f;
	private boolean isProgrammer = true;
	
	@Autowired
	private Address address;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public float getHeoght() {
		return heoght;
	}

	public void setHeoght(float heoght) {
		this.heoght = heoght;
	}

	public boolean isProgrammer() {
		return isProgrammer;
	}

	public void setProgrammer(boolean isProgrammer) {
		this.isProgrammer = isProgrammer;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", heoght=" + heoght + ", isProgrammer=" + isProgrammer
				+ ", address=" + address + "]";
	}
	
	

}
