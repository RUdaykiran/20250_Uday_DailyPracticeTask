package com.sonata.jpassion.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sonata.jpassion.di.services.CustomerService;

public class Main {

	public static void main(String[] args) {

		// Create a new AnnotationConfigApplicationContext, deriving bean
		// definitions from the given annotated classes and automatically
		// refreshing the context. Note that we don't use a context
		// configuration file in this example.
		ApplicationContext context = new AnnotationConfigApplicationContext(
				BeanConfiguration.class);

		CustomerService customerService = (CustomerService) context
				.getBean(CustomerService.class);
		System.out.println(customerService.getCustomerGreeting());

		((ConfigurableApplicationContext) context).close();
	}
}

