package com.sonata.AddressInterface;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("myaddress")
public class Address implements AddressInterface{
	private int streetnumber = 5;
	private String city = "Vijayawada";
	private String state= "A.P";
	private String country= "India";
	
	
	public int getStreetnumber() {
		return streetnumber;
	}
	public void setStreetnumber(int streetnumber) {
		this.streetnumber = streetnumber;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	@Override
	public String getAddress() {
		String compAdd = "Address is :" + getStreetnumber() + getCity() + getState() + getCountry();
		return compAdd;
	}

}
