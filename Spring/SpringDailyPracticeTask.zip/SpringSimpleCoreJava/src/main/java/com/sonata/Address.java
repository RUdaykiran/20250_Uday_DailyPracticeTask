package com.sonata;

import org.springframework.stereotype.Component;

@Component
public class Address {
	private int steertNumber = 12;
	private String streetName = "Santhi Nagar";
	private String city = "Vijayawada";
	private String country = "India";
	public int getSteertNumber() {
		return steertNumber;
	}
	public void setSteertNumber(int steertNumber) {
		this.steertNumber = steertNumber;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	@Override
	public String toString() {
		return "Address [steertNumber=" + steertNumber + ", streetName=" + streetName + ", city=" + city + ", country="
				+ country + "]";
	}
	
	
	

}
