package com.sonata.ServiceAnnotation.dao;

public interface CustumerDao {
	public String getCustomerName();
}
