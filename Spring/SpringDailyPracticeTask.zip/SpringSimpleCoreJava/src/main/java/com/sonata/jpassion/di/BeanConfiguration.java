package com.sonata.jpassion.di;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sonata.jpassion.di.dao.CustomerDao;
import com.sonata.jpassion.di.dao.CustomerDaoImpl;
import com.sonata.jpassion.di.services.CustomerService;
import com.sonata.jpassion.di.services.CustomerServiceImpl;

@Configuration
public class BeanConfiguration {
	
	@Bean
	public CustomerService getCustomerService() {
		CustomerService customerService = new CustomerServiceImpl();
		return customerService;
	}
	
	@Bean
	public CustomerDao getCustomerDao() {
		CustomerDao customerDao = new CustomerDaoImpl();
		return customerDao;
	}

}

