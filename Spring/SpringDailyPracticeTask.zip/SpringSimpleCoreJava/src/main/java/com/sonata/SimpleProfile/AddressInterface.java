package com.sonata.SimpleProfile;

public interface AddressInterface {
	String getWholeAddress();
}