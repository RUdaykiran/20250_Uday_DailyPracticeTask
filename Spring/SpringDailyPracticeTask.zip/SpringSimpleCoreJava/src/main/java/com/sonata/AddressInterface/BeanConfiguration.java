package com.sonata.AddressInterface;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {
	@Bean(name ="Address")
	public AddressInterface getAddress()
	{
		AddressInterface address = new Address();
		return address;

	}


}
