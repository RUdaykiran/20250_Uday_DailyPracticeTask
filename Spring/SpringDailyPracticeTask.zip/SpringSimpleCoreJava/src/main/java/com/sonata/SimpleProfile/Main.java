package com.sonata.SimpleProfile;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.AbstractEnvironment;

@Configuration
@ComponentScan
public class Main {

	public static void main(String[] args) {
		
		String myProfile = "myaddress";
		if (args.length == 1) {
			myProfile = args[0];
		}

		// Set the active profile of Spring application
		System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME,
				myProfile);
		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(
				Main.class);
        Person person = (Person)ctx.getBean(Person.class);
        System.out.println(getPersonInfo(person));
    }
      
    public static String getPersonInfo(Person person) {
        return    "Name:" + person.getName() + "\n"
                + "Age:" + person.getAge() + "\n"
                + "Height: " + person.getHeight() + "\n"
                + "Is Programmer?: " + person.isProgrammer() + "\n"
                + "Address: " + person.getAddress().getWholeAddress();
    }
}
