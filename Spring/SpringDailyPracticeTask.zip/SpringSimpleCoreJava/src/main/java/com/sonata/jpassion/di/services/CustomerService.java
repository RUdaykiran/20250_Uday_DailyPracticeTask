package com.sonata.jpassion.di.services;

public interface CustomerService {
	public String getCustomerGreeting();
}
