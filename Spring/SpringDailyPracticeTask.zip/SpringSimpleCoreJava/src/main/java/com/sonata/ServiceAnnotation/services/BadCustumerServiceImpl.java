package com.sonata.ServiceAnnotation.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.sonata.ServiceAnnotation.dao.CustumerDao;

@Service
@Profile("badcustomer")
public class BadCustumerServiceImpl implements CustomerService {
	
	@Autowired
	CustumerDao customerDao;

	public String getCustomerGreeting() {
		String greeting = customerDao.getCustomerName() + " is a bad customer." ;
		return greeting;
	}

}

