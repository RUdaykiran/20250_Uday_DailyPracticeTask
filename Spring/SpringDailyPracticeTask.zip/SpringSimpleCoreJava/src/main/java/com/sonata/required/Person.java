package com.sonata.required;

import org.springframework.beans.factory.annotation.Required;


public class Person {

	private String name = "Sang Shin";
	private int age = 77;
	private float height = 1.99f;
	private boolean isProgrammer = true;

	private Address address;

	public Address getAddress() {
		return address;
	}

	// @Required annotation does not work well with
	// Java configuration given that Spring does not
	// have a clean way of detecting if an object (Address
	// object in the example below) has been initialized or not.  
	@Required
	public void setAddress(Address address) {
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public float getHeight() {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	public boolean isProgrammer() {
		return isProgrammer;
	}

	public void setProgrammer(boolean isProgrammer) {
		this.isProgrammer = isProgrammer;
	}

}

