package com.sonata.AddressInterface;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Person {
	private String name= "Uday";
	private int age = 21;
	private float height = 6.0f;
	private boolean isProgrammer = true;
	
	@Autowired
	private AddressInterface address;
	
	public AddressInterface getAddress()
	{
		return address;
	}
	//private Address address;
	/*@Resource
	public void setAddress(Address address)
	{
		this.address= address;
	}*/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public float getHeight() {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	public boolean isProgrammer() {
		return isProgrammer;
	}

	public void setProgrammer(boolean isProgrammer) {
		this.isProgrammer = isProgrammer;
	}


	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", height=" + height + ", isProgrammer=" + isProgrammer + "]";
	}
	
}