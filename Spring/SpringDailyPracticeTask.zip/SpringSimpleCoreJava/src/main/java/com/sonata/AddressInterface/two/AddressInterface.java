package com.sonata.AddressInterface.two;

public interface AddressInterface {
	String getWholeAddress();
}
