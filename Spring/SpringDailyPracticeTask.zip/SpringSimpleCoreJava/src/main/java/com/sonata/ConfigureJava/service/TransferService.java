package com.sonata.ConfigureJava.service;

public interface TransferService {

	void transfer(double amount, String srcAcctId, String destAcctId);

}
