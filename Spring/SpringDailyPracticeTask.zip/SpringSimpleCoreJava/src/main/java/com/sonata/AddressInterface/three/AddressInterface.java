package com.sonata.AddressInterface.three;

public interface AddressInterface {
	String getWholeAddress();
}
