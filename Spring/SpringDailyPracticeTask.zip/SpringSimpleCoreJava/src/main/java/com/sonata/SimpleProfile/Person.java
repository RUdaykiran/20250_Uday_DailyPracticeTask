package com.sonata.SimpleProfile;

public class Person {

}
