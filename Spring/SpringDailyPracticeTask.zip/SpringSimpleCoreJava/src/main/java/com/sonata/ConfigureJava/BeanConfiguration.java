package com.sonata.ConfigureJava;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sonata.ConfigureJava.repository.AccountRepository;
import com.sonata.ConfigureJava.repository.InMemoryAccountRepository;
import com.sonata.ConfigureJava.service.TransferService;
import com.sonata.ConfigureJava.service.TransferServiceImpl;

@Configuration
public class BeanConfiguration {

	@Bean
	public TransferService transferService() {
		return new TransferServiceImpl(accountRepository());
	}

	@Bean
	public AccountRepository accountRepository() {
		return new InMemoryAccountRepository();
	}

}
