package com.sonata.ServiceAnnotation.services;

public interface CustomerService {
	public String getCustomerGreeting();
}
