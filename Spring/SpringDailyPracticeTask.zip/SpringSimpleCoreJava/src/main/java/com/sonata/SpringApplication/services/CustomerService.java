package com.sonata.SpringApplication.services;

public interface CustomerService {
	public String getCustomerGreeting();
}
