package com.sonata.AddressInterface;

public interface AddressInterface {
	public String getAddress();

}