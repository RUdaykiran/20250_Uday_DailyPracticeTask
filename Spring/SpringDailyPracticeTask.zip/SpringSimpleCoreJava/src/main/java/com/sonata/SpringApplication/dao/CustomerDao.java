package com.sonata.SpringApplication.dao;

public interface CustomerDao {
	public String getCustomerName();
}