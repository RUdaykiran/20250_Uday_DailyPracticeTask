package com.sonata.SpringApplication;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class BeanConfiguration {
	
//	@Bean
//	public CustomerService getCustomerService() {
//		CustomerService customerService = new CustomerServiceImpl();
//		return customerService;
//	}
//	
//	@Bean
//	public CustomerDao getCustomerDao() {
//		CustomerDao customerDao = new CustomerDaoImpl();
//		return customerDao;
//	}

}

