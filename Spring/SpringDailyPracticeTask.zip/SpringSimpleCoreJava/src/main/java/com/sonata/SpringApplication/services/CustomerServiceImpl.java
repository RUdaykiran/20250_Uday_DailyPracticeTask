package com.sonata.SpringApplication.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpassion.di.dao.CustomerDao;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerDao customerDao;

	public String getCustomerGreeting() {
		String greeting = "Hello, " + customerDao.getCustomerName();
		return greeting;
	}

}

