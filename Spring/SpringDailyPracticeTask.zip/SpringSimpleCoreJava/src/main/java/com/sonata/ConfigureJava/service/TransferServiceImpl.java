package com.sonata.ConfigureJava.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sonata.AddressInterface.BeanConfiguration;
import com.sonata.ConfigureJava.domain.Account;
import com.sonata.ConfigureJava.repository.AccountRepository;
import com.sonata.ConfigureJava.service.TransferService;

public class TransferServiceImpl implements TransferService{
	public static void main(String[] args) {

		// Create a new AnnotationConfigApplicationContext, deriving bean
		// definitions from the given annotated classes and automatically
		// refreshing the context. 
		ApplicationContext ctx = new AnnotationConfigApplicationContext(
				BeanConfiguration.class);

		// retrieve the beans we'll use during testing
		AccountRepository accountRepository = ctx.getBean(AccountRepository.class);
		TransferService transferService = ctx.getBean(TransferService.class);

		// create accounts to test against
		accountRepository.add(new Account("A123", 1000.00));
		accountRepository.add(new Account("C456", 0.00));

		System.out.println("accountRepository.findById(\"A123\").getBalance() = "
				+ accountRepository.findById("A123").getBalance());
		System.out.println("accountRepository.findById(\"C456\").getBalance() = "
				+ accountRepository.findById("C456").getBalance());

		// perform transfer
		System.out.println("Transfering 100 dollars from A123 to C456 ");
		transferService.transfer(100.00, "A123", "C456");

		System.out.println("accountRepository.findById(\"A123\").getBalance() = "
				+ accountRepository.findById("A123").getBalance());
		System.out.println("accountRepository.findById(\"C456\").getBalance() = "
				+ accountRepository.findById("C456").getBalance());
		
		((ConfigurableApplicationContext)ctx).close();

	}

	@Override
	public void transfer(double amount, String srcAcctId, String destAcctId) {
		// TODO Auto-generated method stub
		
	}
}
