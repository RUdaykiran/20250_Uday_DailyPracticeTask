package com.sonata.jpassion.di.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sonata.jpassion.di.dao.CustomerDao;
import com.sonata.ServiceAnnotation.dao.CustumerDao;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustumerDao customerDao;

	public String getCustomerGreeting() {
		String greeting = "Hello, " + customerDao.getCustomerName();
		return greeting;
	}

}

