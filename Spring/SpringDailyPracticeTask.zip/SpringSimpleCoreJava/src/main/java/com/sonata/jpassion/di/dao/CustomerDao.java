package com.sonata.jpassion.di.dao;

public interface CustomerDao {
	public String getCustomerName();
}