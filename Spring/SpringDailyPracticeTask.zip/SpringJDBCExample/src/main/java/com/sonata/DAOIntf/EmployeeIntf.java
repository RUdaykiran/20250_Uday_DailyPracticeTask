package com.sonata.DAOIntf;

import java.util.List;

import com.sonata.Model.Employee;

public interface EmployeeIntf {
	
	public List<Employee> getAllEmployee(); 

}
