package com.sonata;

public class MyController {

}
